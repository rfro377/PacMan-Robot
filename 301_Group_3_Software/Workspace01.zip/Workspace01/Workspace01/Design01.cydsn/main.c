/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>


/* Macros */

#define LOW (0)
#define HIGH (1)

/* Global Varibles */
    int16 adcVal;
    int16 mVolts;
    uint8 dataReady= 0;

int main()
{
    /* Enable global interrupts. */
    CyGlobalIntEnable; 
    
    
    //Practical Test Modes
    
    //***************************************
    ADC_SAR_1_Enable();
    ADC_SAR_1_Start();
    ADC_SAR_1_IRQ_Enable();
    ADC_SAR_1_StartConvert();
    PWM_1_Start();
    //PIN MAP//
    //ADC 1.6
    //ADCREF 0.2
    //PWM 2.4
    //PWM 2.5
    //***************************************
    
    
    int i = 0;
    /* ADC Start Components */
    
    
    
    
    
    
    /* Interupts */
   // ADC_SAR_1_IRQ_StartEx(ADC_ISR_Handler); 
    
  

    for(;;)
    {
        if(i < 240000){
            PWM_1_WriteCompare1(15000);
            PWM_1_WriteCompare2(15000);
        }
        else if(i < 480000){    
            PWM_1_WriteCompare1(0);
            PWM_1_WriteCompare2(0);
        }
        else if(i < 720000){
            PWM_1_WriteCompare1(50000);
            PWM_1_WriteCompare2(50000);
        }else{
            PWM_1_WriteCompare1(0);
            PWM_1_WriteCompare2(0);
        }
        i++;
        if(i > 960000){
            i = 0;
        }
        /* TEST ADC CODE. */
        
        adcVal = ADC_SAR_1_GetResult16();
        adcVal = ADC_SAR_1_CountsTo_mVolts(adcVal); 
        if(adcVal < 2500){
            LED_Write(LOW);
        }else{
            LED_Write(HIGH);
        }
        
        


        
    }
}



/* [] END OF FILE */
